const shell = require('shelljs');
shell.rm('-f', './src/env.json');